# TRINX Android

Proyecto Android nativo de TRINX (MVP 0.2.0).

## Contenido
- Reproductor local con AndroidX Media3 (ExoPlayer).
- Importación de varios archivos de audio desde el dispositivo.
- Interfaz Compose en tema oscuro con marca TRINX.
- Dependencias y configuración Gradle Kotlin DSL.

## Compilar
Abre la carpeta `TRINX` como proyecto en Android Studio y ejecuta `assembleDebug`.

Requiere JDK 17, Android SDK 35 y conexión a internet para descargar dependencias.
