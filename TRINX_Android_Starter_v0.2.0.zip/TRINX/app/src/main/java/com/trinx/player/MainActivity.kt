package com.trinx.player

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer

private val Ink = Color(0xFF050505)
private val Panel = Color(0xFF151515)
private val Line = Color(0xFF292929)
private val Accent = Color(0xFFFFFFFF)
private val Muted = Color(0xFF9A9A9A)
private val SoftPanel = Color(0xFF202020)

data class LocalTrack(val uri: Uri, val title: String, val subtitle: String)

class MainActivity : ComponentActivity() {
    private var player: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        setContent {
            TrinxApp(
                player = player!!,
                onPickAudio = { uris ->
                    val tracks = uris.mapIndexed { index, uri ->
                        runCatching {
                            contentResolver.takePersistableUriPermission(
                                uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
                            )
                        }
                        val name = queryDisplayName(uri) ?: "Pista ${index + 1}"
                        LocalTrack(uri, name.substringBeforeLast('.', name), "Archivo local · calidad original")
                    }
                    player!!.clearMediaItems()
                    val mediaItems = tracks.map { track ->
                        MediaItem.Builder()
                            .setUri(track.uri)
                            .setMediaMetadata(
                                MediaMetadata.Builder()
                                    .setTitle(track.title)
                                    .setArtist("Archivo local")
                                    .build()
                            )
                            .build()
                    }
                    player!!.setMediaItems(mediaItems)
                    if (tracks.isNotEmpty()) {
                        player!!.prepare()
                        player!!.playWhenReady = true
                    }
                    tracks
                }
            )
        }
    }

    private fun queryDisplayName(uri: Uri): String? = runCatching {
        contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { cursor ->
                if (cursor.moveToFirst()) cursor.getString(0) else null
            }
    }.getOrNull()

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TrinxApp(player: ExoPlayer, onPickAudio: (List<Uri>) -> List<LocalTrack>) {
    var tracks by remember { mutableStateOf(listOf<LocalTrack>()) }
    var selectedTab by remember { mutableStateOf("Inicio") }
    var isPlaying by remember { mutableStateOf(false) }
    var currentTitle by remember { mutableStateOf("Tu música, sin límites") }
    var currentSubtitle by remember { mutableStateOf("Añade archivos para comenzar") }
    var search by remember { mutableStateOf("") }

    val picker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        if (uris.isNotEmpty()) {
            val imported = onPickAudio(uris)
            tracks = imported.distinctBy { it.uri }
        }
    }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                currentTitle = mediaItem?.mediaMetadata?.title?.toString() ?: "Reproduciendo"
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent, secondary = Muted, background = Ink, surface = Panel,
            onBackground = Color.White, onSurface = Color.White
        )
    ) {
        Scaffold(
            containerColor = Ink,
            bottomBar = {
                NavigationBar(containerColor = Panel) {
                    listOf("Inicio", "Biblioteca", "Favoritos").forEach { tab ->
                        NavigationBarItem(
                            selected = selectedTab == tab,
                            onClick = { selectedTab = tab },
                            icon = {
                                Icon(
                                    imageVector = when (tab) {
                                        "Favoritos" -> Icons.Default.Favorite
                                        "Biblioteca" -> Icons.Default.FolderOpen
                                        else -> Icons.Default.GraphicEq
                                    }, contentDescription = tab
                                )
                            },
                            label = { Text(tab) }
                        )
                    }
                }
            }
        ) { padding ->
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding),
                contentPadding = PaddingValues(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 24.dp),
                verticalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("TRINX", color = Color.White, fontWeight = FontWeight.Black, letterSpacing = 6.sp, fontSize = 20.sp)
                            Text("AUDIO PLAYER", color = Muted, fontWeight = FontWeight.Medium, letterSpacing = 2.sp, fontSize = 9.sp)
                            Text("Tu mundo,\ntu música.", color = Color.White, fontSize = 30.sp, lineHeight = 34.sp, fontWeight = FontWeight.Bold)
                        }
                        Box(
                            Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(Color.White),
                            contentAlignment = Alignment.Center
                        ) {
                            Canvas(Modifier.size(27.dp)) {
                                val sw = 5.dp.toPx()
                                drawLine(Color.Black, androidx.compose.ui.geometry.Offset(size.width * .18f, size.height * .18f), androidx.compose.ui.geometry.Offset(size.width * .82f, size.height * .82f), sw, cap = androidx.compose.ui.graphics.StrokeCap.Round)
                                drawLine(Color.Black, androidx.compose.ui.geometry.Offset(size.width * .82f, size.height * .18f), androidx.compose.ui.geometry.Offset(size.width * .18f, size.height * .82f), sw, cap = androidx.compose.ui.graphics.StrokeCap.Round)
                            }
                        }
                    }
                }
                item {
                    OutlinedTextField(
                        value = search, onValueChange = { search = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("Buscar canciones o artistas") },
                        singleLine = true, shape = RoundedCornerShape(18.dp),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color.White, unfocusedBorderColor = Line,
                            focusedContainerColor = Panel, unfocusedContainerColor = Panel
                        )
                    )
                }
                item {
                    Box(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(28.dp))
                            .background(SoftPanel)
                            .padding(22.dp)
                    ) {
                        Column(verticalArrangement = Arrangement.spacedBy(13.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("EXPERIENCIA TRINX", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                                Spacer(Modifier.weight(1f))
                                Box(Modifier.size(34.dp).clip(CircleShape).background(Color.White), contentAlignment = Alignment.Center) {
                                    Canvas(Modifier.size(19.dp)) {
                                        val sw = 3.5.dp.toPx()
                                        drawLine(Color.Black, androidx.compose.ui.geometry.Offset(size.width * .18f, size.height * .18f), androidx.compose.ui.geometry.Offset(size.width * .82f, size.height * .82f), sw, cap = androidx.compose.ui.graphics.StrokeCap.Round)
                                        drawLine(Color.Black, androidx.compose.ui.geometry.Offset(size.width * .82f, size.height * .18f), androidx.compose.ui.geometry.Offset(size.width * .18f, size.height * .82f), sw, cap = androidx.compose.ui.graphics.StrokeCap.Round)
                                    }
                                }
                            }
                            Text("Escucha cada\ndetalle.", color = Color.White, fontSize = 29.sp, lineHeight = 32.sp, fontWeight = FontWeight.Bold)
                            Text("Tu colección personal. Sonido original, sin compresión añadida por TRINX.", color = Color.White.copy(alpha = .72f), fontSize = 14.sp)
                            Button(
                                onClick = { picker.launch(arrayOf("audio/*")) },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Ink)
                            ) {
                                Icon(Icons.Default.FolderOpen, null)
                                Spacer(Modifier.width(8.dp))
                                Text("Importar mi música", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("TU COLECCIÓN", color = Muted, fontSize = 10.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                            Spacer(Modifier.weight(1f))
                            Text("LOCAL · PRIVADA", color = Muted, fontSize = 9.sp, letterSpacing = 1.sp)
                    }
                }
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            when (selectedTab) {
                                "Biblioteca" -> "Tu biblioteca"
                                "Favoritos" -> "Tus favoritos"
                                else -> "Escuchadas recientemente"
                            },
                            color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                        Text("${tracks.size} pistas", color = Muted)
                    }
                }
                if (tracks.isEmpty()) {
                    item {
                        Box(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).background(Panel).padding(24.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Icon(Icons.Default.MusicNote, null, tint = Color.White, modifier = Modifier.size(36.dp))
                                Text("Todavía no hay música", fontWeight = FontWeight.SemiBold)
                                Text("Pulsa «Añadir música» y selecciona tus archivos.", color = Color.LightGray)
                            }
                        }
                    }
                } else {
                    itemsIndexed(tracks.filter { it.title.contains(search, ignoreCase = true) }) { index, track ->
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Panel)
                                .clickable {
                                    val originalIndex = tracks.indexOf(track)
                                    if (originalIndex >= 0) {
                                        player.seekTo(originalIndex, 0)
                                        player.play()
                                    }
                                }.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.size(48.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF252525)), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.MusicNote, null, tint = Color.White)
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(track.title, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text(track.subtitle, color = Color.LightGray, fontSize = 12.sp)
                            }
                            IconButton(onClick = {
                                val position = tracks.indexOf(track)
                                if (position >= 0) { player.seekTo(position, 0); player.play() }
                            }) { Icon(Icons.Default.PlayArrow, "Reproducir") }
                        }
                    }
                }
                item {
                    Column(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Panel).padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text("REPRODUCIENDO", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                        Text(currentTitle, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(currentSubtitle, color = Color.LightGray, fontSize = 12.sp)
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { player.seekToPreviousMediaItem() }) { Icon(Icons.Default.SkipPrevious, "Anterior") }
                            FilledIconButton(onClick = {
                                if (player.isPlaying) player.pause() else player.play()
                            }, modifier = Modifier.size(56.dp)) {
                                Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, if (isPlaying) "Pausar" else "Reproducir")
                            }
                            IconButton(onClick = { player.seekToNextMediaItem() }) { Icon(Icons.Default.SkipNext, "Siguiente") }
                        }
                    }
                }
                item {
                    Text("TRINX · VERSION 0.3.0", color = Color.Gray, fontSize = 11.sp, modifier = Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                }
            }
        }
    }
}
